📌 Disclaimer 📌

Please use this program only for educational purposes. It is not meant to be used in any malicious way, and I decline any responsibility for what you do with it.

Discord : https://discord.gg/RdVX95ysyA

Code created by catcha80#2887

How to install and run:

Download the zip file of the tool.

Install all the modules:

Open a cmd (windows + r cmd) and install all the modules 
- pip install discum 
- pip install random 
- pip install time

Last step, run the file.

If you have a question, join my discord.
